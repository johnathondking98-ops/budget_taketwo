import { useState } from 'react';
import { Alert } from 'react-native';

// All persistence is handled by Firebase in App.js.
// This hook only provides in-memory helper functions.
export const useGroceries = (groceryItems, setGroceryItems, history, setHistory) => {

  // ... (Keep your addItem, deleteItem, etc. exactly the same as before) ...
  // (I will assume you have those functions from previous steps)
  
  // Just ensure handleCheckout uses the safety spread:
  const handleCheckout = () => {
    // ... logic ...
         const timestamp = new Date().toISOString().split('T')[0];
         const archived = checkedItems.map(i => ({ ...i, date: timestamp }));
         
         // SAFETY SPREAD
         setHistory(prev => [...(prev || []), ...archived]);
         setGroceryItems(prev => prev.filter(i => !i.checked));
    // ... logic ...
  };
  
  // ... rest of return statement ...
  const addItem = (name, price = '0', quantity = 1) => {
    const newItem = {
      id: Date.now().toString(),
      name,
      price: parseFloat(price),
      quantity: parseInt(quantity),
      checked: false
    };
    setGroceryItems(prev => [...prev, newItem]);
  };
  
  const toggleCheck = (id) => {
    setGroceryItems(prev => prev.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };
  
  const deleteItem = (id) => {
    setGroceryItems(prev => prev.filter(item => item.id !== id));
  };
  
  const calculateTotal = () => {
    return groceryItems.reduce((sum, item) => {
      return sum + ((parseFloat(item.price) || 0) * (item.quantity || 1));
    }, 0).toFixed(2);
  };

  const [isScanning, setIsScanning] = useState(false);
  const simulateScan = (callback) => {
    setIsScanning(true);
    setTimeout(() => {
      addItem("Scanned Item", (Math.random() * 10).toFixed(2));
      setIsScanning(false);
      if (callback) callback(); 
      Alert.alert("Scanned!", "Item added to cart.");
    }, 1500);
  };

  return { addItem, toggleCheck, deleteItem, handleCheckout, calculateTotal, simulateScan, isScanning };
};