// All persistence is handled via Firebase (see App.js).
// This file is kept as a stub in case a local-storage fallback is needed in the future.

export const useStorage = () => {
  const saveItem = async (_key, _value) => {};
  const getItem = async (_key) => null;
  return { saveItem, getItem };
};