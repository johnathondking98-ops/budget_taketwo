import firebase from 'firebase/app';
require( 'firebase/database');

const firebaseConfig = {
  apiKey: "AIzaSyBY0UCxmiHZQJmDqVvRzL7RMSpvO7PxHfQ",
  authDomain: "family-finance-686cb.firebaseapp.com",
  databaseURL: "https://family-finance-686cb-default-rtdb.firebaseio.com",
  projectId: "family-finance-686cb",
  storageBucket: "family-finance-686cb.firebasestorage.app",
  messagingSenderId: "176719391741",
  appId: "1:176719391741:web:1394d37496558e12834794"
};

// This check is much safer
if (firebase && firebase.apps && firebase.apps.length === 0) {
  firebase.initializeApp(firebaseConfig);
}

// If firebase is undefined for some reason, we export null 
// so App.js doesn't crash but knows to wait.
export const db = firebase.database("https://family-finance-686cb-default-rtdb.firebaseio.com");

export default firebase;